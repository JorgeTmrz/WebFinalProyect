
<?php $__env->startSection('contenido'); ?>
    dskds
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\final\resources\views/user.blade.php ENDPATH**/ ?>